function plotResults(actual, forecasts, legendNames)
    figure;
    plot(actual, 'k', 'LineWidth', 2, 'DisplayName', 'Actual');
    hold on;
    colors = {'b', 'r', 'g', 'm', 'c', 'y'};
    for i = 1:length(forecasts)
        plot(forecasts{i}, colors{i}, 'DisplayName', legendNames{i});
    end
    title('Wind Speed Forecasts at 100m');
    legend;
    xlabel('Time Interval');
    ylabel('Wind Speed at 100m (m/s)');
    hold off;
end
