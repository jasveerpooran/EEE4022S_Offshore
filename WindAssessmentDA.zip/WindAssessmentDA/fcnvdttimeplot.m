function fcnvdttimeplot(wind)
% fcnvdttimeplot.m plot 
% 
% This function plots the velocity, direction, and temperature time-series
% data. 
% 
% Usage: fcnvdttimeplot(wind)
% 
% Inputs:
% wind = dataset array with all data
% 
% Outputs: None

% Copyright 2009 - 2011 MathWorks, Inc.

% Find begining of all months in date range
m = getMonth(wind.t);
y = getYear(wind.t);

dateGroups = unique([y m], 'rows');
dateGroups = sortrows(dateGroups,[1 2]);
dateGroups = dateGroups(1:2:length(dateGroups),:);
xt = datenum([dateGroups ones(size(dateGroups,1),1) ... 
    zeros(size(dateGroups,1),1) ones(size(dateGroups,1),1) ... 
    zeros(size(dateGroups,1),1)]);

% Create figure
sp1 = subplot(3,1,1);
    plot(wind.t,wind.S20,wind.t,wind.S60,wind.t,wind.S100,wind.t,wind.S120,wind.t,wind.S160)
    legend('S20','S60','S100','S120','S160')
    ylabel('v_{avg} (m/s)')
    set(gca,'XTick',xt)
    set(gca,'XTickLabel',cell(1,length(xt)))
sp2 = subplot(3,1,2);
    plot(wind.t,wind.D20,wind.t,wind.D60,wind.t,wind.D100,wind.t,wind.D120,wind.t,wind.D160)
    legend('D20','D60','D100','D120','D160')
    ylabel('d_{avg} (deg)')
    set(gca,'XTick',xt)
    set(gca,'XTickLabel',cell(1,length(xt)))
sp3 = subplot(3,1,3);
    plot(wind.t,wind.T2)
    legend('T2')
    ylabel('T_{avg} (K)')
    set(gca,'XTick',xt)
    datetick('x','mmm-yy','keeplimits','keepticks')
linkaxes([sp1, sp2, sp3], 'x');

% [EOF]