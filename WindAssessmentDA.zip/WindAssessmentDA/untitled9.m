% Load the data
data = readtable('wasa3-timeseries-171-488--29.8812-31.0717.csv');
wind_speed_100m = data.S100; 

forecasting_period = 16; % 8 hours with 30-minute intervals

% Extracting the last part of the static training data
training_data_static = wind_speed_100m(end-forecasting_period-100+1:end-forecasting_period);
last_values = training_data_static(end-10:end);

% Display the last few data points
fprintf('Last 10 values from static training data:\n');
disp(last_values);
