function [forecast, best_alpha] = adaptive_regressive_smoothing(train_data, test_data, alpha_range)
    % Initialize variables
    min_mse = inf;
    best_alpha = NaN;
    forecast = zeros(size(test_data));

    % Loop over the range of alpha values to find the best alpha
    for current_alpha = alpha_range
        temp_forecast = zeros(size(test_data));
        temp_forecast(1) = train_data(end); % Initialize with the last value of training data
        running_sum = train_data(end); % Initialize with the last value of training data
        
        for t = 2:length(test_data) % Start from t=2
            % Update the running sum
            running_sum = current_alpha * (running_sum + (1-current_alpha)^(t-1) * train_data(end-t+2));
            
            % Calculate the adjustment
            previous_value = train_data(end-t+2);
            if t == 2
                second_previous_value = train_data(end); % Last value of training data
            else
                second_previous_value = test_data(t-2);
            end
            
            adjustment = (1-current_alpha)^t * (previous_value + (previous_value - second_previous_value));
            
            % Combine the running sum and adjustment to get the forecast
            temp_forecast(t) = running_sum + adjustment;
        end
        
        % Calculate the mean squared error for this alpha
        mse = mean((temp_forecast(2:end) - test_data(2:end)).^2);
        if mse < min_mse
            min_mse = mse;
            best_alpha = current_alpha;
            forecast = temp_forecast;
        end
    end
end
