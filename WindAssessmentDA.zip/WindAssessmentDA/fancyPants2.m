% Load the data
data = readtable('Cape Town location.csv');

% Consider only the last two years
two_years_data = 2 * 365 * 24 * 2; % 2 years with 30-minute intervals
wind_speed_100m = data.S100(end-two_years_data+1:end); 

% Split the data
training_percentage = 0.70;
validation_percentage = 0.15;
training_data_len = floor(two_years_data * training_percentage);
validation_data_len = floor(two_years_data * validation_percentage);
testing_data_len = two_years_data - training_data_len - validation_data_len;

training_data = wind_speed_100m(1:training_data_len);
validation_data = wind_speed_100m(training_data_len+1:training_data_len+validation_data_len);
testing_data = wind_speed_100m(training_data_len+validation_data_len+1:end);

window_size = 100;
alphas = 0.50:0.01:0.99;

best_alpha = 0;
lowest_RMSE = inf;

% Model selection using validation set
for alpha = alphas
    F1 = zeros(size(validation_data));
    weighted_sum = training_data(end); % Start with the last value of the training set
    
    for t = 2:length(validation_data)
        % Update the weighted sum
        weighted_sum = alpha * validation_data(t-1) + (1-alpha) * weighted_sum;
        part1 = weighted_sum;
        part2 = (1-alpha)^(t-1) * (validation_data(t-1) + (validation_data(t-1) - validation_data(t)));
        
        % Store the forecast
        F1(t) = part1 + part2;
    end
    
    % Compute RMSE for this alpha using validation data
    errors = validation_data - F1;
    RMSE = sqrt(mean(errors.^2));
    
    if RMSE < lowest_RMSE
        lowest_RMSE = RMSE;
        best_alpha = alpha;
    end
end

% Testing the model using the best alpha and testing data
F1 = zeros(size(testing_data));
weighted_sum = validation_data(end); % Start with the last value of the validation set

for t = 2:length(testing_data)
    % Update the weighted sum
    weighted_sum = alpha * testing_data(t-1) + (1-alpha) * weighted_sum;
    part1 = weighted_sum;
    part2 = (1-alpha)^(t-1) * (testing_data(t-1) + (testing_data(t-1) - testing_data(t)));
    
    % Store the forecast
    F1(t) = part1 + part2;
end

% Compute error metrics using testing data
errors = testing_data - F1;
MAE = mean(abs(errors));
MSE = mean(errors.^2);
RMSE = sqrt(MSE);
non_zero_indices = testing_data ~= 0; % Indices where wind_speed_100m is not zero
MAPE = mean(abs(errors(non_zero_indices) ./ testing_data(non_zero_indices))) * 100;

% Display the metrics for the best alpha
fprintf('Best Alpha: %.2f\n', best_alpha);
fprintf('MAE: %.4f\n', MAE);
fprintf('MSE: %.4f\n', MSE);
fprintf('RMSE: %.4f\n', RMSE);
fprintf('MAPE: %.4f%%\n', MAPE);
fprintf('------------------\n');
forecasting_period = 16;
% Print the actual vs forecasted values for the last 8-hour window
fprintf('Time\tActual\tForecasted\n');
fprintf('-----------------------------\n');
for i = 1:forecasting_period
    actual_value = testing_data(end-forecasting_period+i);
    forecasted_value = F1(end-forecasting_period+i);  % Changed from 'best_forecasts' to 'F1'
    fprintf('%d\t%.4f\t%.4f\n', i, actual_value, forecasted_value);
end

% Plot the actual vs forecasted values for the last 8-hour window
figure;
plot(testing_data(end-forecasting_period+1:end), 'b'); % Actual data for the last 8 hours
hold on;
plot(F1(end-forecasting_period+1:end), 'r'); % Forecasted data for the last 8 hours
legend('Actual', 'Forecasted with Best Alpha');
title('Adaptive-1 Regressive Smoothing Forecasts for the Last 8 Hours');
xlabel('Time');
ylabel('Wind Speed (m/s)');
grid on;

% Print the last window_size + forecasting_period values of testing_data to check the data
fprintf('\nLast values of wind_speed_100m:\n');
fprintf('-----------------------------\n');
for i = length(testing_data)-window_size-forecasting_period+1:length(testing_data)
    fprintf('Time %d: %.4f\n', i, testing_data(i));
end
