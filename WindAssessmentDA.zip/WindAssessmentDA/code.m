%% Import Data
% Read the data from your file
wind = readtable('Cape Town location.csv');
% Convert date to a Serial Date Number (1 = January 1, 0000 A.D.)
wind.t = datenum(wind.Time,'yyyy/mm/dd HH:MM');

%% Handle Missing Data
% Replace NaN values with the mean of each column
for varName = wind.Properties.VariableNames
    if isnumeric(wind.(varName{1}))
        meanValue = nanmean(wind.(varName{1}));
        wind.(varName{1})(isnan(wind.(varName{1}))) = meanValue;
    end
end

% Filter only the data for 2018
startIndex = find(wind.t >= datenum('2018-01-01 00:00', 'yyyy-mm-dd HH:MM') & ...
                  wind.t < datenum('2019-01-01 00:00', 'yyyy-mm-dd HH:MM'));

data2018 = wind(startIndex,:);

% Plotting the data for 2018
figure;
plot(data2018.t, data2018.S100);
xlabel('Time (2020)');
ylabel('S100 Values');
title('S100 Values for 2018');

% Customizing the x-axis to represent the months of 2020
xticks(datenum({'2020-01-01', '2020-02-01', '2020-03-01', '2020-04-01', '2020-05-01', '2020-06-01', ...
                '2020-07-01', '2020-08-01', '2020-09-01', '2020-10-01', '2020-11-01', '2020-12-01'}, ...
               'yyyy-mm-dd'));
xticklabels({'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'});
