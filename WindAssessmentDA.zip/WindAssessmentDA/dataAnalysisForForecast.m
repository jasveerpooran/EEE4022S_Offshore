%% Load the Data
data = readtable('wasa3-timeseries-171-488--29.8812-31.0717.csv');
wind_speed_100m = data.S100;
times = datetime(data.Time, 'InputFormat', 'yyyy/MM/dd HH:mm');

%% Visualize the Entire Time Series
figure;
plot(times, wind_speed_100m);
xlabel('Time');
ylabel('Wind Speed at 100m (m/s)');
title('Time Series of Wind Speed at 100m');
grid on;

%% Visualize Seasonal Patterns (Monthly Averages)
monthly_avg = movmean(wind_speed_100m, [30*24*15, 0]);  % Average over approximately a month
figure;
plot(times, monthly_avg);
xlabel('Time');
ylabel('Monthly Average Wind Speed at 100m (m/s)');
title('Monthly Averages of Wind Speed at 100m');
grid on;

%% Check for Trends (Yearly Averages)
yearly_avg = movmean(wind_speed_100m, [365*24*30/2, 0]);  % Average over approximately a year
figure;
plot(times, yearly_avg);
xlabel('Time');
ylabel('Yearly Average Wind Speed at 100m (m/s)');
title('Yearly Averages of Wind Speed at 100m');
grid on;

%% Histogram of Wind Speeds
figure;
histogram(wind_speed_100m, 50);
xlabel('Wind Speed at 100m (m/s)');
ylabel('Frequency');
title('Histogram of Wind Speeds at 100m');
grid on;

%% Extract Data for Each Season
months = month(times);
summer_data = wind_speed_100m(months == 12 | months == 1 | months == 2);
autumn_data = wind_speed_100m(months == 3 | months == 4 | months == 5);
winter_data = wind_speed_100m(months == 6 | months == 7 | months == 8);
spring_data = wind_speed_100m(months == 9 | months == 10 | months == 11);

%% Visualize Average Wind Speed for Each Season
avg_summer = mean(summer_data);
avg_autumn = mean(autumn_data);
avg_winter = mean(winter_data);
avg_spring = mean(spring_data);
figure;
bar([avg_summer, avg_autumn, avg_winter, avg_spring]);
xticks(1:4);
xticklabels({'Summer', 'Autumn', 'Winter', 'Spring'});
ylabel('Average Wind Speed at 100m (m/s)');
title('Seasonal Averages of Wind Speed at 100m');
grid on;

%% Visualize Monthly Averages to Understand Seasonal Transition
monthly_avg = accumarray(months, wind_speed_100m, [], @mean);
figure;
bar(monthly_avg);
xticks(1:12);
xticklabels({'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'});
ylabel('Average Wind Speed at 100m (m/s)');
title('Monthly Averages of Wind Speed at 100m');
grid on;


%% Descriptive Statistics
disp('Overall Descriptive Statistics:');
disp([mean(wind_speed_100m), median(wind_speed_100m), std(wind_speed_100m), min(wind_speed_100m), max(wind_speed_100m)]);

% Seasonal descriptive statistics
disp('Summer Descriptive Statistics:');
disp([mean(summer_data), median(summer_data), std(summer_data), min(summer_data), max(summer_data)]);
% Repeat for other seasons...


%% Autocorrelation and Partial Autocorrelation
% The `autocorr` and `parcorr` functions from the Econometrics Toolbox can be used.
% If you have the toolbox, you can uncomment and use the following:
% Compute ACF and PACF values up to 40 lags
lags = 40;
[acf_val, acf_lags] = autocorr(wind_speed_100m, lags);
[pacf_val, pacf_lags] = parcorr(wind_speed_100m, lags);

% Print ACF and PACF values
disp('ACF Values:');
disp(acf_val);

disp('PACF Values:');
disp(pacf_val);
 
 figure;
 autocorr(wind_speed_100m);
 figure;
 parcorr(wind_speed_100m);

%% Daily and Weekly Profiles
hours = hour(times);
days = weekday(times);  % 1 = Sunday, 2 = Monday, ..., 7 = Saturday

% Daily profile
hourly_avg = accumarray(hours+1, wind_speed_100m, [], @mean);
figure;
plot(0:23, hourly_avg);
xlabel('Hour of the Day');
ylabel('Average Wind Speed at 100m (m/s)');
title('Hourly Profile of Wind Speed');
grid on;

% Weekly profile
weekly_avg = accumarray(days, wind_speed_100m, [], @mean);
figure;
bar(1:7, weekly_avg);
xticks(1:7);
xticklabels({'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'});
ylabel('Average Wind Speed at 100m (m/s)');
title('Weekly Profile of Wind Speed');
grid on;

%% Seasonal Box Plots
figure;
boxplot(wind_speed_100m, months);
xlabel('Month');
ylabel('Wind Speed at 100m (m/s)');
title('Monthly Boxplots of Wind Speed');
grid on;


%% Overall Descriptive Statistics
disp('Overall Descriptive Statistics:');
disp(['Mean: ', num2str(mean(wind_speed_100m))]);
disp(['Median: ', num2str(median(wind_speed_100m))]);
disp(['Standard Deviation: ', num2str(std(wind_speed_100m))]);
disp(['Min: ', num2str(min(wind_speed_100m))]);
disp(['Max: ', num2str(max(wind_speed_100m))]);

% Seasonal Descriptive Statistics
% Summer
disp('Summer Descriptive Statistics:');
disp(['Mean: ', num2str(mean(summer_data))]);
disp(['Median: ', num2str(median(summer_data))]);
disp(['Standard Deviation: ', num2str(std(summer_data))]);
% Autumn Descriptive Statistics
disp('Autumn Descriptive Statistics:');
disp(['Mean: ', num2str(mean(autumn_data))]);
disp(['Median: ', num2str(median(autumn_data))]);
disp(['Standard Deviation: ', num2str(std(autumn_data))]);
disp(['Min: ', num2str(min(autumn_data))]);
disp(['Max: ', num2str(max(autumn_data))]);

% Winter Descriptive Statistics
disp('Winter Descriptive Statistics:');
disp(['Mean: ', num2str(mean(winter_data))]);
disp(['Median: ', num2str(median(winter_data))]);
disp(['Standard Deviation: ', num2str(std(winter_data))]);
disp(['Min: ', num2str(min(winter_data))]);
disp(['Max: ', num2str(max(winter_data))]);

% Spring Descriptive Statistics
disp('Spring Descriptive Statistics:');
disp(['Mean: ', num2str(mean(spring_data))]);
disp(['Median: ', num2str(median(spring_data))]);
disp(['Standard Deviation: ', num2str(std(spring_data))]);
disp(['Min: ', num2str(min(spring_data))]);
disp(['Max: ', num2str(max(spring_data))]);


% Autocorrelation Value at Lag 1
autocorr_value = corr(wind_speed_100m(1:end-1), wind_speed_100m(2:end));
disp(['Autocorrelation at Lag 1: ', num2str(autocorr_value)]);

% Percentiles
disp(['5th Percentile: ', num2str(prctile(wind_speed_100m, 5))]);
disp(['25th Percentile: ', num2str(prctile(wind_speed_100m, 25))]);
disp(['75th Percentile: ', num2str(prctile(wind_speed_100m, 75))]);
disp(['95th Percentile: ', num2str(prctile(wind_speed_100m, 95))]);

% Number of Missing Values
num_missing = sum(isnan(wind_speed_100m));
disp(['Number of Missing Values: ', num2str(num_missing)]);

% Yearly Growth Rate
% Assuming the data is uniformly spaced, we can compute an average growth rate
yearly_avg = arrayfun(@(y) mean(wind_speed_100m(year(times) == y)), unique(year(times)));
yearly_growth_rate = diff(yearly_avg) ./ yearly_avg(1:end-1);
disp(['Average Yearly Growth Rate: ', num2str(mean(yearly_growth_rate))]);

% Skewness and Kurtosis
disp(['Skewness: ', num2str(skewness(wind_speed_100m))]);
disp(['Kurtosis: ', num2str(kurtosis(wind_speed_100m))]);

% Volatility (Rolling Standard Deviation)
rolling_window = 30*24*2; % Approximately a month
volatility = movstd(wind_speed_100m, rolling_window);
disp(['Average Monthly Volatility: ', num2str(mean(volatility))]);

% Frequency of Extreme Values
extreme_high = prctile(wind_speed_100m, 95);
extreme_low = prctile(wind_speed_100m, 5);
num_extreme_high = sum(wind_speed_100m > extreme_high);
num_extreme_low = sum(wind_speed_100m < extreme_low);
disp(['Number of Values Above 95th Percentile: ', num2str(num_extreme_high)]);
disp(['Number of Values Below 5th Percentile: ', num2str(num_extreme_low)]);

% Cross-Correlation with Temperature
[cc, lags] = xcorr(wind_speed_100m, data.T2, 'coeff');
[~, idx] = max(abs(cc)); % Find the lag with the maximum absolute correlation
disp(['Max Cross-Correlation with Temperature at Lag: ', num2str(lags(idx))]);

% Number of Zero-Wind Events
num_zero_wind = sum(wind_speed_100m == 0);
disp(['Number of Zero-Wind Events: ', num2str(num_zero_wind)]);


%% 
% %Thank you for sharing the updated output. Let's dive deeper into these results:
% 
% 1. **Seasonal Descriptive Statistics**:
%    - **Summer**: The mean wind speed is approximately \(7.84 \, \text{m/s}\) with a standard deviation of \(3.95 \, \text{m/s}\). This suggests that wind speeds during summer are slightly higher than the overall average and are less variable.
%    - **Autumn**: The mean wind speed drops a bit to \(7.30 \, \text{m/s}\) with a similar variability (\(3.96 \, \text{m/s}\)). The max wind speed during this season is noticeably lower than in summer.
%    - **Winter**: Winter has a very similar mean wind speed to Autumn (\(7.33 \, \text{m/s}\)), but the variability (standard deviation) increases to \(4.34 \, \text{m/s}\), suggesting more fluctuating wind speeds during this season. The maximum wind speed in winter is also higher than in autumn.
%    - **Spring**: Spring sees a noticeable increase in the mean wind speed to \(8.61 \, \text{m/s}\) with the highest variability of all seasons at \(4.43 \, \text{m/s}\). This suggests that spring is the windiest season for this location.
% 
% 2. **Autocorrelation**: The very high autocorrelation value at lag 1 suggests that wind speeds are highly dependent on their immediate past values, indicating a strong persistence in the time series.
% 
% 3. **Distribution Characteristics**:
%    - The skewness and kurtosis values, along with the percentiles, further support the observation that the distribution of wind speeds is slightly right-skewed with occasional higher-than-average wind speeds.
%    - The majority of the wind speeds lie between \(1.85 \, \text{m/s}\) and \(15.47 \, \text{m/s}\), as indicated by the 5th and 95th percentiles.
% 
% 4. **Volatility & Extremes**:
%    - The average monthly volatility indicates how much the wind speed fluctuates within a month.
%    - The number of values above the 95th percentile and below the 5th percentile indicates that extreme wind speeds (both high and low) occur relatively frequently.
% 
% 5. **Correlation with Temperature**: The maximum cross-correlation with temperature occurs at a lag of 5, suggesting a possible relationship between temperature changes and wind speed changes with a slight delay.
% 
% 6. **Zero-Wind Events**: The presence of only one zero-wind event in the entire dataset suggests that calm periods (with no wind) are quite rare.
% 
% **Key Insights**:
% - Spring seems to be the windiest season, with the highest mean wind speed and variability.
% - The wind speed time series is highly persistent, with a value largely dependent on its previous value.
% - The distribution of wind speeds is slightly right-skewed, with occasional periods of higher-than-average wind speeds.
% - There seems to be a potential relationship between temperature changes and wind speed changes, worth exploring further.
% 




%%

% Extract temperature data
T2 = data.T2;

% Ensure that the wind speed and temperature data have the same length
assert(length(wind_speed_100m) == length(T2), 'Data lengths mismatch!');

% Remove NaN values from train_data and train_temp
idx = ~isnan(wind_speed_100m) & ~isnan(T2);

filtered_wind_speed = wind_speed_100m(idx);
filtered_temp = T2(idx);
filtered_times = times(idx);  % Filter the times based on the index

% Convert the data to daily averages
daily_times = unique(dateshift(filtered_times, 'start', 'day'));
daily_wind_speed = accumarray(findgroups(floor(filtered_times)), filtered_wind_speed, [], @mean);
daily_temp = accumarray(findgroups(floor(filtered_times)), filtered_temp, [], @mean);

% Split data into training and test sets
train_data = daily_wind_speed(daily_times < datetime('2019-01-01'));
train_temp = daily_temp(daily_times < datetime('2019-01-01'));
test_data = daily_wind_speed(daily_times >= datetime('2019-01-01'));

disp(['Size of train_data: ', num2str(length(train_data))]);
disp(['Size of train_temp: ', num2str(length(train_temp))]);

% Model 1 (Alternative): SARIMA(0,1,0)(1,1,1)[365] with temperature as an exogenous variable
Mdl1 = arima('D', 1, 'SARLags', 365, 'Seasonality', 365);
EstMdl1 = estimate(Mdl1, train_data, 'X', train_temp);

% Model 2: Simplified SARIMA(0,1,0)(1,1,1)[365]
Mdl2 = arima('D', 1, 'SARLags', 365, 'Seasonality', 365);
EstMdl2 = estimate(Mdl2, train_data);

% Forecasting with Model 1 (Alternative)
[Y1, YVariance1] = forecast(EstMdl1, numel(test_data), 'Y0', train_data, 'X0', train_temp, 'XF', daily_temp(daily_times >= datetime('2019-01-01')));

% Forecasting with Model 2
[Y2, YVariance2] = forecast(EstMdl2, numel(test_data), 'Y0', train_data);

% Calculate Mean Squared Errors (MSE) for both models
MSE1 = mean((test_data - Y1).^2);
MSE2 = mean((test_data - Y2).^2);

disp(['MSE for Model 1 (Alternative SARIMA(0,1,0)(1,1,1)[365] with temperature): ', num2str(MSE1)]);
disp(['MSE for Model 2 (SARIMA(0,1,0)(1,1,1)[365]): ', num2str(MSE2)]);

% Plot actual vs. forecasted values for the better model
figure;
plot(daily_times(daily_times >= datetime('2019-01-01')), test_data);
hold on;

if MSE1 < MSE2
    plot(daily_times(daily_times >= datetime('2019-01-01')), Y1, 'r', 'LineWidth', 2);
    title('Wind Speed Forecast vs. Actual (Model 1 Alternative)');
else
    plot(daily_times(daily_times >= datetime('2019-01-01')), Y2, 'r', 'LineWidth', 2);
    title('Wind Speed Forecast vs. Actual (Model 2)');
end

legend('Actual', 'Forecast');
