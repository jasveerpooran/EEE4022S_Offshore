function [X, y] = preprocess_data(data, window_size)
    num_samples = length(data) - window_size;
    X = zeros(num_samples, window_size);
    y = zeros(num_samples, 1);
    
    for i = 1:num_samples
        X(i, :) = data(i:i+window_size-1);
        y(i) = data(i+window_size);
    end
    X = X';
    y = y';
end
