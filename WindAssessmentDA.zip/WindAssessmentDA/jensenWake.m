% Jensen's Wake Model
function [reducedSpeed] = jensenWake(U0, x, D, CT)
    a = 0.25 * (1 - sqrt(1 - CT));
    delta = 0.1; % Increase from 0.075 to 0.1
    reducedSpeed = U0 * (1 - (2 * a) / (1 + delta * x / D)^2);
end