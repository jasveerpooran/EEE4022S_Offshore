% Load the data
data = readtable('wasa3-timeseries-171-488--29.8812-31.0717.csv');
data.t = datenum(data.Time,'yyyy/mm/dd HH:MM');  % Convert date to a Serial Date Number
wind_speed_100m = data.S100;

% Define alpha value
alpha = 0.92;

% Define training windows and forecasting period
forecastingPeriod = datenum(2019,12,31,16,0,0):datenum(0,0,0,0,30,0):datenum(2019,12,31,23,30,0);
eight_hour_train_end = datenum(2019,12,31,15,30,0);
one_week_train_start = eight_hour_train_end - 6;
one_month_train_start = eight_hour_train_end - 29;

% Static Window Forecasting

% 8-hour training dataset
train_data = wind_speed_100m(data.t > (eight_hour_train_end - 8/24) & data.t <= eight_hour_train_end);
test_data = wind_speed_100m(data.t > eight_hour_train_end & data.t <= forecastingPeriod(end));

% Adaptive 1-Regressive Smoothing Forecast for 8-hour training window
forecast_8hr = zeros(length(test_data), 1);
for t = 1:length(test_data)
    % Concatenate train_data with test_data up to current time step
    data_combined = [train_data; test_data(1:t-1)];
    len = length(data_combined);
    
    % Calculate forecast for current time step
    sum_term = alpha * sum((1 - alpha).^(0:len-1) .* flip(data_combined));
    
    if t == 1
        previous_value = train_data(end);
    else
        previous_value = test_data(t-1);
    end
    adaptive_term = (1 - alpha)^len * (data_combined(end) + (data_combined(end) - previous_value));
    forecast_8hr(t) = sum_term + adaptive_term;
end

% Repeat the above process for 1-week and 1-month windows...

% Rolling Window Forecasting

% Define the rolling window size (e.g., 1 week)
window_size = 7 * 48; % 7 days * 48 half-hour intervals

% Initialize arrays to store rolling forecasts
rolling_forecast = zeros(length(wind_speed_100m) - window_size, 1);

% Rolling window forecasting
for i = 1:48:(length(wind_speed_100m) - window_size)
    train_data = wind_speed_100m(i:(i+window_size-1));
    test_data = wind_speed_100m(i+window_size:i+window_size+47);
    
    % Adaptive 1-Regressive Smoothing Forecast for rolling window
    for t = 1:length(test_data)
        % Concatenate train_data with test_data up to current time step
        data_combined = [train_data; test_data(1:t-1)];
        len = length(data_combined);
        
        % Calculate forecast for current time step
        sum_term = alpha * sum((1 - alpha).^(0:len-1) .* flip(data_combined));
        
        if t == 1
            previous_value = train_data(end);
        else
            previous_value = test_data(t-1);
        end
        adaptive_term = (1 - alpha)^len * (data_combined(end) + (data_combined(end) - previous_value));
        rolling_forecast(t) = sum_term + adaptive_term;
    end
end

% Evaluation (calculate MAE) can be added here...

% Visualization (plot actual vs. forecasted values) can be added here...
