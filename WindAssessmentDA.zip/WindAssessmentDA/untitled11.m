% -----------------------
% Data Loading and Preprocessing
% -----------------------

% Load your data
wind = readtable('wasa3-timeseries-171-488--29.8812-31.0717.csv');
wind.t = datenum(wind.Time,'yyyy/mm/dd HH:MM');

% Create variable to store statistical analysis results
wresults = [];       % Structure variable for results

% -----------------------
% Find the Best Alpha Value
% -----------------------

% Define alpha values to test
alpha_values = 0.01:0.01:0.99;

% Initialize variables to store results
best_alpha = [];
best_rmse = inf;

% Split data into training and validation sets (adjust as needed)
training_data = wind(1:end-8, :); % Assuming 8-hour intervals
validation_data = wind(end-7:end, :); % Validation data (adjust as needed)

for alpha = alpha_values
    % Implement the Adaptive Regressive Smoothing Model with the current alpha
    forecasts = nan(size(training_data, 1), 1);

    for t = 2:size(training_data, 1)
        forecasts(t) = alpha * training_data{t - 1, 'S100'} + (1 - alpha) * (forecasts(t - 1) - training_data{t - 1, 'S100'});
    end

    % Calculate RMSE on the validation set
    rmse = sqrt(mean((forecasts - validation_data{:, 'S100'}).^2));

    % Update best alpha if the current alpha gives a lower RMSE
    if rmse < best_rmse
        best_alpha = alpha;
        best_rmse = rmse;
    end
end

fprintf('Best Alpha Value: %.2f\n', best_alpha);

% -----------------------
% Compare Using a Rolling Window
% -----------------------

% Define window sizes and forecasting periods
window_sizes = [8, 24, 720];
forecasting_hours = [16:23];

% Loop through different window sizes
for window_size = window_sizes
    fprintf('Window Size: %d\n', window_size);

    % Loop through the forecasting hours
    for hour = forecasting_hours
        fprintf('Forecasting Hour: %02d\n', hour);

        % Find training and forecasting indices

        % Adjust as needed to find training and forecasting indices
        % For example, if you want 8-hour training data:
        training_start = find(wind.t >= datenum('2019/12/31 07:30'), 1);
        training_end = find(wind.t >= datenum('2019/12/31 15:30'), 1);
        training_indices = training_start:training_end;

        % Forecasting period
        forecasting_start = find(wind.t >= datenum(['2019/12/31 ' num2str(hour) ':00']), 1);
        forecasting_end = forecasting_start + window_size - 1;
        forecasting_indices = forecasting_start:forecasting_end;

        % Split data into training and forecasting sets
        training_data = wind(training_indices, :);
        forecasting_data = wind(forecasting_indices, :);

        % Implement the Adaptive Regressive Smoothing Model using 'S100' column
        forecasts = nan(size(training_data, 1), 1);

        for t = 2:size(training_data, 1)
            forecasts(t) = best_alpha * training_data{t - 1, 'S100'} + (1 - best_alpha) * (forecasts(t - 1) - training_data{t - 1, 'S100'});
        end

        % Calculate and display performance metrics (e.g., RMSE)
        rmse = sqrt(mean((forecasts - forecasting_data{:, 'S100'}).^2));
        fprintf('RMSE: %.2f\n', rmse);

        % Plot the forecasts and actual values

        % Implement plotting code here
        % You can use MATLAB's plotting functions to visualize the results
        % Example:
        % figure;
        % plot(forecasting_data.t, forecasting_data.S100, 'b', 'LineWidth', 2);
        % hold on;
        % plot(forecasting_data.t, forecasts, 'r', 'LineWidth', 2);
        % xlabel('Time');
        % ylabel('Wind Speed (S100)');
        % legend('Actual', 'Forecast');
        % title('Wind Speed Forecasting for S100');
        % grid on;
    end
end
