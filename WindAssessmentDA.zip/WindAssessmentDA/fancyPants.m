% Load the data
data = readtable('Cape Town location.csv');
wind_speed_100m = data.S100; 

forecasting_period = 16; % 8 hours with 30-minute intervals
training_data = wind_speed_100m(end-forecasting_period-100+1:end-forecasting_period); % Use the last 100 data points excluding the forecasting window

best_alpha = 0;
lowest_RMSE = inf;

alphas = 0.1:0.1:0.9; % Alpha values to test

for alpha = alphas
    % Initialize forecast array
    F1 = zeros(size(training_data));
    
    % Compute forecasts using Adaptive-1 Regressive Smoothing Method for the training data
    for t = 2:length(training_data)
        % Directly compute the weighted sum
        weighted_sum = 0;
        for j = 1:t-1
            weight = alpha * (1-alpha)^(t-j-1);
            weighted_sum = weighted_sum + weight * training_data(j);
        end
        
        % Calculate the forecast
        part1 = weighted_sum;
        part2 = (1-alpha)^t * (training_data(t-1) + (training_data(t-1) - training_data(t)));
        
        % Store the forecast
        F1(t) = part1 + part2;
    end
    
    % Compute RMSE for training data
    errors = training_data - F1;
    RMSE = sqrt(mean(errors.^2));
    
    % Check if this RMSE is the lowest
    if RMSE < lowest_RMSE
        lowest_RMSE = RMSE;
        best_alpha = alpha;
    end
end

% Using best alpha, forecast the next 16 points dynamically
forecasted_values = zeros(forecasting_period, 1);
for t = 1:forecasting_period
    all_data = [training_data; forecasted_values(1:t-1)]; % Include previous forecasted values
    current_point = length(all_data);
    
    weighted_sum = 0;
    for j = 1:current_point
        weight = best_alpha * (1-best_alpha)^(current_point-j);
        weighted_sum = weighted_sum + weight * all_data(j);
    end
    
    part1 = weighted_sum;
    if current_point > 1
        part2 = (1-best_alpha)^current_point * (all_data(current_point-1) + (all_data(current_point-1) - all_data(current_point)));
    else
        part2 = 0;
    end
    
    forecasted_values(t) = part1 + part2;
end

% Display the results
fprintf('Best alpha: %.1f\n', best_alpha);
fprintf('Lowest RMSE from training data: %.4f\n', lowest_RMSE);
fprintf('\nTime\tActual\tForecasted\n');
fprintf('-----------------------------\n');
for i = 1:forecasting_period
    actual_value = wind_speed_100m(end-forecasting_period+i);
    forecasted_value = forecasted_values(i);
    fprintf('%d\t%.4f\t%.4f\n', i, actual_value, forecasted_value);
end
