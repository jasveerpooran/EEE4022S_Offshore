%% Import Data
wind = readtable('wasa3-timeseries-171-488--29.8812-31.0717.csv');
wind.t = datenum(wind.Time,'yyyy/mm/dd HH:MM');

% Extract wind speed data at 100m
wind_speed = wind.S100;

%% Basic Time Series Plot
figure;
plot(wind.t, wind_speed);
xlabel('Time');
ylabel('Wind Speed at 100m (m/s)');
title('Wind Speed Time Series');
datetick('x','yyyy-mm-dd', 'keepticks', 'keeplimits');
grid on;

%% Zoomed-In Plot for a Month
figure;
start_date = datenum('2019-12-01 00:00','yyyy-mm-dd HH:MM');
end_date = datenum('2019-12-31 23:30','yyyy-mm-dd HH:MM');
idx = find(wind.t >= start_date & wind.t <= end_date);
plot(wind.t(idx), wind_speed(idx));
xlabel('Time');
ylabel('Wind Speed at 100m (m/s)');
title('Wind Speed for December 2019');
datetick('x','yyyy-mm-dd', 'keepticks', 'keeplimits');
grid on;

%% Histogram
figure;
histogram(wind_speed,50); % 50 bins
xlabel('Wind Speed at 100m (m/s)');
ylabel('Frequency');
title('Histogram of Wind Speeds');

%% Autocorrelation Plot
figure;
autocorr(wind_speed, 100); % 100 lags
title('Autocorrelation of Wind Speeds');

%% Extract Metrics
% Mean and Median
wind_speed_mean = mean(wind_speed);
wind_speed_median = median(wind_speed);

% Standard Deviation
wind_speed_std = std(wind_speed);

% Displaying the metrics
fprintf('Mean Wind Speed: %f m/s\n', wind_speed_mean);
fprintf('Median Wind Speed: %f m/s\n', wind_speed_median);
fprintf('Standard Deviation of Wind Speed: %f m/s\n', wind_speed_std);
