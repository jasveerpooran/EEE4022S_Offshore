function error = evaluateForecast(actual, forecasted)
    error = mean(abs(actual - forecasted));
end
