function fcnalphaplot(X1, Y1, Y2)
% fcnalphaplot(X1,Y1,Y2)
%   X1:  vector of x data (month-year combinations as datenum)
%   Y1:  vector of y data (monthly shear exponent values)
%   Y2:  overall average shear exponent value

% Generate month-year labels from X1
dateLabels = datestr(X1, 'mmm-yy');

% Create figure
figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1);
set(axes1, 'XTick', 1:length(X1)); % Set x-axis ticks based on the number of month-year combinations
set(axes1, 'XTickLabel', dateLabels); % Set x-axis tick labels to the month-year labels
xlim(axes1, [1 length(X1)]); % Set x-axis limits
box(axes1, 'on');
hold(axes1, 'all');

% Create plot for monthly values
plot(Y1, 'Parent',axes1, 'MarkerFaceColor',[0 0 1], 'Marker','o', 'LineStyle',':', 'DisplayName','Monthly');

% Create ylabel
ylabel('\alpha');

% Create plot for overall average value
plot(ones(size(Y1)) * Y2, 'Parent',axes1, 'LineWidth',2, 'Color',[0.8471 0.1608 0], 'DisplayName','Overall');

% Create legend
legend(axes1,'show');

end
