%% Load and Preprocess Data
data = readtable('wasa3-timeseries-171-488--29.8812-31.0717.csv');
data.Time = datetime(data.Time,'InputFormat','yyyy/MM/dd HH:mm');
timetableData = table2timetable(data);
data_1D = retime(timetableData, 'daily', 'mean');

% Add lagged wind speed
data_1D.S100_lag1 = [NaN; data_1D.S100(1:end-1)];

%% Set Training Data Index
train_idx = year(data_1D.Time) < 2019;

%% Simple Model (Linear Regression as OLS approximation)
X_train = data_1D.S100_lag1(train_idx);
y_train = data_1D.S100(train_idx);
mdl_simple = fitlm(X_train, y_train);

%% Random Forest Model
% Convert D100 from WRF frame to earth frame
data_1D.D100 = mod(data_1D.D100 + 353.12, 360);
data_1D.spd_rolling_3 = movmean(data_1D.S100, 3, 'omitnan');
data_1D.spd_rolling_5 = movmean(data_1D.S100, 5, 'omitnan');
data_1D.S100_lag2 = lagmatrix(data_1D.S100, 2);
data_1D.D100_sin = sin(2 * pi * data_1D.D100 / 360);
data_1D.D100_cos = cos(2 * pi * data_1D.D100 / 360);

%% Feature Engineering

% Rolling standard deviation
data_1D.spd_std_3 = movstd(data_1D.S100, 3, 'omitnan');
data_1D.spd_std_5 = movstd(data_1D.S100, 5, 'omitnan');

% Seasonality
dayOfYear = day(data_1D.Time, 'dayofyear');
data_1D.day_sin = sin(2 * pi * dayOfYear / 365);
data_1D.day_cos = cos(2 * pi * dayOfYear / 365);

% Update the training feature matrix for Random Forest
X_forest = [data_1D.S100_lag1(train_idx), data_1D.S100_lag2(train_idx), data_1D.T2(train_idx), data_1D.spd_rolling_3(train_idx), data_1D.spd_rolling_5(train_idx), month(data_1D.Time(train_idx)), data_1D.D100_sin(train_idx), data_1D.D100_cos(train_idx), data_1D.spd_std_3(train_idx), data_1D.spd_std_5(train_idx), data_1D.day_sin(train_idx), data_1D.day_cos(train_idx)];

% Random sample for initial testing
sample_idx = randperm(size(X_forest, 1), 1000);
X_forest_sample = X_forest(sample_idx, :);
y_train_sample = y_train(sample_idx);

% Train on sample
mdl_forest_sample = TreeBagger(100, X_forest_sample, y_train_sample, 'OOBPrediction', 'on');

% Display OOB error
oobError = mdl_forest_sample.oobError();
fprintf('Out-of-bag error: %.3f\n', oobError(end));
%% Binned Orthogonal Least Squares
dir_bins = discretize(data_1D.D100, 0:45:360);
bin_models = {};

for i = 1:8
    bin_idx = dir_bins == i & train_idx;
    X_bin = [data_1D.S100_lag1(bin_idx), data_1D.T2(bin_idx)];
    y_bin = data_1D.S100(bin_idx);

    % Remove NaN values
    valid_rows = ~any(isnan(X_bin), 2);
    X_bin = X_bin(valid_rows, :);
    y_bin = y_bin(valid_rows);

    % Check for duplicate rows
    [~,ia,~] = unique(X_bin, 'rows');
    if isempty(ia)
        fprintf('All rows are duplicates for bin %d. Skipping.\n', i);
        bin_models{i} = [];
        continue;
    end
    X_bin = X_bin(ia,:);
    y_bin = y_bin(ia);

    if size(X_bin, 1) > 1
        try
            bin_models{i} = fitlm(X_bin, y_bin);
        catch
            fprintf('Issues with regression for bin %d. Using mean as fallback.\n', i);
            bin_models{i} = [];
        end
    else
        fprintf('Skipping regression for bin %d due to insufficient data points.\n', i);
        bin_models{i} = [];
    end
end

%% Evaluation
% Predictions for simple linear regression model
X_test_simple = data_1D.S100_lag1(~train_idx);
y_pred_simple = predict(mdl_simple, X_test_simple);

% Form the test feature matrix for random forest
X_test_forest = [data_1D.S100_lag1(~train_idx), data_1D.S100_lag2(~train_idx), data_1D.T2(~train_idx), data_1D.spd_rolling_3(~train_idx), data_1D.spd_rolling_5(~train_idx), month(data_1D.Time(~train_idx)), data_1D.D100_sin(~train_idx), data_1D.D100_cos(~train_idx), data_1D.spd_std_3(~train_idx), data_1D.spd_std_5(~train_idx), data_1D.day_sin(~train_idx), data_1D.day_cos(~train_idx)];

y_true = data_1D.S100(~train_idx);

y_pred_forest_cell = predict(mdl_forest_sample, X_test_forest);
y_pred_forest = str2double(y_pred_forest_cell);

% Predictions for Binned Orthogonal Least Squares model
X_test_binned = [data_1D.S100_lag1(~train_idx), data_1D.T2(~train_idx)];
y_pred_binned = zeros(size(y_true));

for i = 1:8
    bin_idx_test = (dir_bins(~train_idx) == i);
    if ~isempty(bin_models{i})
        y_pred_binned(bin_idx_test) = predict(bin_models{i}, X_test_binned(bin_idx_test, :));
    else
        y_pred_binned(bin_idx_test) = mean(y_train);  % fallback to mean when no model for the bin
    end
end

% Error metrics for all models
rmse_simple = sqrt(mean((y_pred_simple - y_true).^2));
rmse_forest = sqrt(mean((y_pred_forest - y_true).^2));
rmse_binned = sqrt(mean((y_pred_binned - y_true).^2));
mape_simple = mean(abs((y_true - y_pred_simple) ./ y_true)) * 100;
mape_forest = mean(abs((y_true - y_pred_forest) ./ y_true)) * 100;
mape_binned = mean(abs((y_true - y_pred_binned) ./ y_true)) * 100;
mbe_simple = mean(y_pred_simple - y_true);
mbe_forest = mean(y_pred_forest - y_true);
mbe_binned = mean(y_pred_binned - y_true);
mae_simple = mean(abs(y_pred_simple - y_true));
mae_forest = mean(abs(y_pred_forest - y_true));
mae_binned = mean(abs(y_pred_binned - y_true));
mse_simple = mean((y_pred_simple - y_true).^2);
mse_forest = mean((y_pred_forest - y_true).^2);
mse_binned = mean((y_pred_binned - y_true).^2);

% Display error metrics
fprintf('Simple Model - RMSE: %.3f, MAPE: %.3f%%, MBE: %.3f, MAE: %.3f, MSE: %.3f\n', rmse_simple, mape_simple, mbe_simple, mae_simple, mse_simple);
fprintf('Random Forest - RMSE: %.3f, MAPE: %.3f%%, MBE: %.3f, MAE: %.3f, MSE: %.3f\n', rmse_forest, mape_forest, mbe_forest, mae_forest, mse_forest);
fprintf('Binned Orthogonal Least Squares - RMSE: %.3f, MAPE: %.3f%%, MBE: %.3f, MAE: %.3f, MSE: %.3f\n', rmse_binned, mape_binned, mbe_binned, mae_binned, mse_binned);

%% Plot Predictions vs. True Values
figure;
plot(data_1D.Time(~train_idx), y_true, 'k', 'LineWidth', 2);
hold on;
plot(data_1D.Time(~train_idx), y_pred_simple, '--');
plot(data_1D.Time(~train_idx), y_pred_forest, ':');
plot(data_1D.Time(~train_idx), y_pred_binned, '-.');
legend('True', 'Simple', 'Random Forest (subset)', 'Binned Orthogonal Least Squares'); 
xlabel('Time');
ylabel('Wind Speed at 100m');


%% --------- HYBRID MODEL -------- %%

%% Hybrid Model

% Determine weights based on RMSE (or another metric of your choice)
forest_weight = 1 / (rmse_forest + rmse_binned);
binned_weight = 1 / (rmse_binned + rmse_forest);

% Normalize the weights so they sum up to 1
total_weight = forest_weight + binned_weight;
forest_weight = forest_weight / total_weight;
binned_weight = binned_weight / total_weight;

% Compute the Hybrid Prediction
y_pred_hybrid = forest_weight * y_pred_forest + binned_weight * y_pred_binned;

% Error metrics for Hybrid model
rmse_hybrid = sqrt(mean((y_pred_hybrid - y_true).^2));
mape_hybrid = mean(abs((y_true - y_pred_hybrid) ./ y_true)) * 100;
mbe_hybrid = mean(y_pred_hybrid - y_true);
mae_hybrid = mean(abs(y_pred_hybrid - y_true));
mse_hybrid = mean((y_pred_hybrid - y_true).^2);

% Display error metrics
fprintf('Hybrid Model - RMSE: %.3f, MAPE: %.3f%%, MBE: %.3f, MAE: %.3f, MSE: %.3f\n', rmse_hybrid, mape_hybrid, mbe_hybrid, mae_hybrid, mse_hybrid);

% Plot Predictions vs. True Values for Hybrid Model
figure;
plot(data_1D.Time(~train_idx), y_true, 'k', 'LineWidth', 2);
hold on;
plot(data_1D.Time(~train_idx), y_pred_simple, '--');
plot(data_1D.Time(~train_idx), y_pred_forest, ':');
plot(data_1D.Time(~train_idx), y_pred_binned, '-.');
plot(data_1D.Time(~train_idx), y_pred_hybrid, '-');
legend('True', 'Simple', 'Random Forest (subset)', 'Binned Orthogonal Least Squares', 'Hybrid'); 
xlabel('Time');
ylabel('Wind Speed at 100m');
