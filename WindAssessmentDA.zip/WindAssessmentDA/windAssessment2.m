%% Import Data
% Read the data from your file
wind = readtable('Cape Town location.csv');
% Convert date to a Serial Date Number (1 = January 1, 0000 A.D.)
wind.t = datenum(wind.Time,'yyyy/mm/dd HH:MM');
%% Handle Missing Data
% Replace NaN values with the mean of each column
for varName = wind.Properties.VariableNames
    if isnumeric(wind.(varName{1}))
        meanValue = nanmean(wind.(varName{1}));
        wind.(varName{1})(isnan(wind.(varName{1}))) = meanValue;
    end
end

% Create variable to store statistical analysis results
wresults = [];       % structure variable for results
%% Visualize Data
% Plot the velocity, direction, and temperature graphs to better understand the data.     
figure
fcnvdttimeplot(wind)

%% Statistical Analysis
% Compute Overall Averages for the dataset
wresults.overall.velocity = mean(double(wind{:, {'S20', 'S60', 'S100', 'S120', 'S160'}}));
wresults.overall.direction = mean(double(wind{:, {'D20', 'D60', 'D100', 'D120', 'D160'}}));
wresults.overall.temperature = mean(double(wind.T2));   
%% Annualized Mean Wind Speed (over the years for different heights)
hub_heights = {'S20', 'S60', 'S100', 'S120', 'S160'};
D = [31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; % Days in each month
wind.Year = year(wind.Time);
wind.Month = month(wind.Time);
unique_years = unique(wind.Year);
annualized_over_years = zeros(length(unique_years), length(hub_heights));
missing_data_S100_December = wind(wind.Year == 2019 & wind.Month == 12 & isnan(wind.S100), :);
for idx = 1:length(unique_years)
    y = unique_years(idx);
    fprintf('Results for Year: %d\n', y);

    annualized_means = zeros(1, length(hub_heights));
    monthly_means_matrix = zeros(12, length(hub_heights));

    year_data = wind(wind.Year == y, :);

    for h = 1:length(hub_heights)
        monthly_means = zeros(1, 12);

        % Calculate monthly means
        for m = 1:12
            monthly_data = year_data(year_data.Month == m, :);
            monthly_means(m) = mean(monthly_data.(hub_heights{h}));
        end

        % Store monthly means
        monthly_means_matrix(:, h) = monthly_means';

        % Calculate the annualized mean
        annualized_means(h) = sum(D .* monthly_means) / 365.25;
    end
    
    annualized_over_years(idx, :) = annualized_means;

    % Create a table for display
    months = {'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'Annualized Mean'};
    T = array2table([monthly_means_matrix; annualized_means], 'VariableNames', hub_heights, 'RowNames', months);

    % Display the table
    disp(T);
    fprintf('\n');
end
% Visualization
% figure;
% plot(unique_years, annualized_over_years, '-o');
% xlabel('Year');
% ylabel('Annualized Mean Wind Speed (m/s)');
% legend(hub_heights, 'Location', 'best');
% title('Annualized Mean Wind Speed Over the Years');
% grid on;
%% Hourly Variability Analysis

% Extract hour from the DateTime column
hours = hour(wind.Time);

% Unique hours
unique_hours = unique(hours);

% Hub heights for speed
hub_heights_speed = {'S100'}; %'S20', 'S60', 'S120', 'S160'

% Preallocate memory
hourly_avg_speed = zeros(length(unique_hours), length(hub_heights_speed));

% Calculate average wind speed for each hour of the day
for h = 1:length(hub_heights_speed)
    for u = 1:length(unique_hours)
        hourly_avg_speed(u, h) = mean(wind.(hub_heights_speed{h})(hours == unique_hours(u)));
    end
end

% % Visualization
% figure;
% plot(unique_hours, hourly_avg_speed);
% legend(hub_heights_speed, 'Location', 'best');
% xlabel('Hour of the Day');
% ylabel('Average Wind Speed (m/s)');
% title('Hourly Variability of Wind Speed');
% grid on;
% xlim([0 23]);
% xticks(0:1:23);

%% Visualisation for Annualised and Hourly Wind Speeds

% Visualization using subplots
figure;

% Subplot for Annualized Mean Wind Speed for S100
subplot(2,1,1);
plot(unique_years, annualized_over_years(:, strcmp(hub_heights, 'S100')), '-o', 'LineWidth', 2,'Color','r');
xlabel('Year');
ylabel('Annualized Mean Wind Speed (m/s)');
title('Annualized Mean Wind Speed over Years at 100m Height');
grid on;
xticks(unique_years);
legend('S100', 'Location', 'best');

% Subplot for Hourly Variability Analysis
subplot(2,1,2);
plot(unique_hours, hourly_avg_speed);
legend(hub_heights_speed, 'Location', 'best');
xlabel('Hour of the Day');
ylabel('Average Wind Speed (m/s)');
title('Hourly Variability of Wind Speed');
grid on;
xlim([0 23]);
xticks(0:1:23);
%% Wind Speed Distribution with Weibull Fit using MATLAB's fitdist and goodnessOfFit

% Extract wind speed data at 100m
windSpeeds100 = wind.S100;

% Remove any NaN or Inf values 
windSpeeds100(isinf(windSpeeds100) | isnan(windSpeeds100)) = [];

% Fit Weibull distribution, with a fallback using initial estimates
try
    [paramEsts, paramCIs] = wblfit(windSpeeds100);
catch
    disp('Initial Weibull fitting failed. Using fallback initial estimates.');
    initialEstimates = [mean(windSpeeds100), std(windSpeeds100)]; 
    [paramEsts, paramCIs] = wblfit(windSpeeds100, 'Start', initialEstimates);
end

% ---- Parameter Estimation ----
disp(['Weibull Shape Parameter (C): ', num2str(paramEsts(2))]);
disp(['Weibull Scale Parameter (Lambda): ', num2str(paramEsts(1))]);
disp(['95% CI for Shape: [', num2str(paramCIs(2,1)), ', ', num2str(paramCIs(2,2)), ']']);
disp(['95% CI for Scale: [', num2str(paramCIs(1,1)), ', ', num2str(paramCIs(1,2)), ']']);

% ---- Validation: Empirical vs Theoretical CDF ----
[f_emp, x_emp] = ecdf(windSpeeds100);
f_theo = wblcdf(x_emp, paramEsts(1), paramEsts(2));
figure;
plot(x_emp, f_emp, 'k-', 'DisplayName', 'Empirical CDF');
hold on;
plot(x_emp, f_theo, 'r--', 'DisplayName', 'Weibull CDF');
xlabel('Wind Speed (m/s)');
ylabel('CDF');
legend;
title('Empirical vs. Theoretical CDF Validation');

% ---- Validation: Histogram vs Weibull PDF ----
figure;
histogram(windSpeeds100, 'Normalization', 'pdf', 'DisplayName', 'Histogram');
hold on;
x = linspace(min(windSpeeds100), max(windSpeeds100), 1000);
y = wblpdf(x, paramEsts(1), paramEsts(2));
plot(x, y, 'r', 'LineWidth', 2, 'DisplayName', 'Weibull PDF');
xlabel('Wind Speed (m/s)');
ylabel('PDF');
legend;
title('Histogram vs. Weibull PDF Validation');

% ---- Validation: Quantitative Goodness-of-Fit Tests ----
% Kolmogorov-Smirnov Test
[h_ks, p_ks] = kstest(windSpeeds100, 'CDF', [x_emp, f_theo]);
disp(['K-S Test result (h-value): ', num2str(h_ks)]);
disp(['K-S Test p-value: ', num2str(p_ks)]);

% ---- Validation: Residual Analysis ----
residuals = f_emp - f_theo;
figure;
plot(x_emp, residuals, 'bo-');
hold on;
plot(x_emp, zeros(size(x_emp)), 'k--'); % Adding reference line
xlabel('Wind Speed (m/s)');
ylabel('Residuals');
title('Residual Analysis');

% ---- Validation: Quantile-Quantile (Q-Q) Plot ----
figure;
qqplot(windSpeeds100, wblrnd(paramEsts(1), paramEsts(2), size(windSpeeds100)));
xlabel('Theoretical Quantiles');
ylabel('Sample Quantiles');
title('Q-Q Plot Validation');

%% Wind Rose with Earth Frame Conversion
% Convert wind direction to earth frame
wind_directions_earth_frame = arrayfun(@(x) mod(x + 353.12, 360), wind{:, {'D20', 'D60', 'D100', 'D120', 'D160'}});

% Create the wind rose plots where the direction represents the direction 
% the wind is blowing from. 

% Use wind_rose function from MATLAB Central with a small modification 
% regarding the meteorological angle conversion.
% (http://www.mathworks.com/matlabcentral/fileexchange/17748)

figure('color','white')
fcnwindrose(wind_directions_earth_frame(:,1), wind.S20, 'dtype', 'meteo', 'n', 16, ...
    'labtitle', 'Height = 20 m', 'lablegend', 'Velocity (m/s)');

figure('color','white')
fcnwindrose(wind_directions_earth_frame(:,2), wind.S60, 'dtype', 'meteo', 'n', 16, ...
    'labtitle', 'Height = 60 m', 'lablegend', 'Velocity (m/s)');

figure('color','white')
fcnwindrose(wind_directions_earth_frame(:,3), wind.S100, 'dtype', 'meteo', 'n', 16, ...
    'labtitle', 'Height = 100 m', 'lablegend', 'Velocity (m/s)');

figure('color','white')
fcnwindrose(wind_directions_earth_frame(:,4), wind.S120, 'dtype', 'meteo', 'n', 16, ...
    'labtitle', 'Height = 120 m', 'lablegend', 'Velocity (m/s)');

figure('color','white')
fcnwindrose(wind_directions_earth_frame(:,5), wind.S160, 'dtype', 'meteo', 'n', 16, ...
    'labtitle', 'Height = 160 m', 'lablegend', 'Velocity (m/s)');


%% Seasonal Analysis for Hub Height "S100"

% Define the seasons for southern hemisphere
seasons = {'Summer', 'Autumn', 'Winter', 'Spring'};
season_months = {[12, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10, 11]};

% Extract month from the date/time data
months = month(wind.Time);

% Preallocate memory for seasonal averages
seasonal_avg_speed_S100 = zeros(1, length(seasons));
seasonal_avg_direction_S100 = zeros(1, length(seasons));

% Calculate averages for each season for hub height "S100"
for s = 1:length(seasons)
    seasonal_data = wind(ismember(months, season_months{s}), :);
    seasonal_avg_speed_S100(s) = mean(seasonal_data.S100);
    seasonal_avg_direction_S100(s) = circ_mean(deg2rad(seasonal_data.D100)); % Circular mean for directions
end

% Visualization for hub height "S100"
figure;

% Average wind speed for S100
subplot(2, 1, 1);
bar(seasonal_avg_speed_S100);
title('Average Wind Speed at S100');
ylabel('Wind Speed (m/s)');
set(gca, 'XTickLabel', seasons);

% Average wind direction for S100
subplot(2, 1, 2);
bar(rad2deg(seasonal_avg_direction_S100));
title('Average Wind Direction at S100');
ylabel('Wind Direction (degrees)');
set(gca, 'XTickLabel', seasons);


%% Seasonal Changes in Wind 
% Import datasets for both coasts
wind_east = readtable('durban fun.csv');
wind_west = readtable('southernMostTip.csv');
wind_east.t = datenum(wind_east.Time,'yyyy/mm/dd HH:MM');
wind_west.t = datenum(wind_west.Time,'yyyy/mm/dd HH:MM');
% Preprocess data
wind_east.Year = year(wind_east.Time);
wind_east.Month = month(wind_east.Time);
wind_west.Year = year(wind_west.Time);
wind_west.Month = month(wind_west.Time);
unique_years_east = unique(wind_east.Year);
unique_years_west = unique(wind_west.Year);
D = [31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
hub_heights = {'S20', 'S60', 'S100', 'S120', 'S160'};

% For 'wind_east' dataset remove NaN values, if any
for h = 1:length(hub_heights)
    col_mean = nanmean(wind_east.(hub_heights{h}));
    wind_east.(hub_heights{h})(isnan(wind_east.(hub_heights{h}))) = col_mean;
end

% For 'wind_west' dataset remove NaN values, if any
for h = 1:length(hub_heights)
    col_mean = nanmean(wind_west.(hub_heights{h}));
    wind_west.(hub_heights{h})(isnan(wind_west.(hub_heights{h}))) = col_mean;
end



% Compute Overall Averages
% For the East Coast
wresults_east.overall.velocity = mean(double(wind_east{:, hub_heights}));
wresults_east.overall.direction = mean(double(wind_east{:, {'D20', 'D60', 'D100', 'D120', 'D160'}}));
% For the West Coast
wresults_west.overall.velocity = mean(double(wind_west{:, hub_heights}));
wresults_west.overall.direction = mean(double(wind_west{:, {'D20', 'D60', 'D100', 'D120', 'D160'}}));

% Annualized Mean Wind Speed for East and West Coasts
annualized_over_years_east = zeros(length(unique_years_east), length(hub_heights));
annualized_over_years_west = zeros(length(unique_years_west), length(hub_heights));

% For East Coast
for idx = 1:length(unique_years_east)
    y = unique_years_east(idx);
    annualized_means = zeros(1, length(hub_heights));
    year_data = wind_east(wind_east.Year == y, :);

    for h = 1:length(hub_heights)
        monthly_means = zeros(1, 12);
        for m = 1:12
            monthly_data = year_data(year_data.Month == m, :);
            monthly_means(m) = mean(monthly_data.(hub_heights{h}));
        end
        annualized_means(h) = sum(D .* monthly_means) / 365.25;
    end
    annualized_over_years_east(idx, :) = annualized_means;
end

% For West Coast
for idx = 1:length(unique_years_west)
    y = unique_years_west(idx);
    annualized_means = zeros(1, length(hub_heights));
    year_data = wind_west(wind_west.Year == y, :);

    for h = 1:length(hub_heights)
        monthly_means = zeros(1, 12);
        for m = 1:12
            monthly_data = year_data(year_data.Month == m, :);
            monthly_means(m) = mean(monthly_data.(hub_heights{h}));
        end
        annualized_means(h) = sum(D .* monthly_means) / 365.25;
    end
    annualized_over_years_west(idx, :) = annualized_means;
end


% Seasonal Analysis
seasons = {'Spring', 'Summer', 'Autumn', 'Winter'};
months_by_season = {[9, 10, 11], [12, 1, 2], [3, 4, 5], [6, 7, 8]};
seasonal_means_east = zeros(length(seasons), length(hub_heights));
seasonal_means_west = zeros(length(seasons), length(hub_heights));

for s = 1:length(seasons)
    for h = 1:length(hub_heights)
        seasonal_means_east(s, h) = mean(wind_east{ismember(wind_east.Month, months_by_season{s}), hub_heights{h}});
        seasonal_means_west(s, h) = mean(wind_west{ismember(wind_west.Month, months_by_season{s}), hub_heights{h}});
    end
end
%%
% Visualization for Comparison
for h = 1:length(hub_heights)
    figure;
    plot(unique_years_east, annualized_over_years_east(:, h), '-o', unique_years_west, annualized_over_years_west(:, h), '-x');
    xlabel('Year');
    ylabel('Annualized Mean Wind Speed (m/s)');
    legend(['East ' + string(hub_heights{h}), 'West ' + string(hub_heights{h})], 'Location', 'best');
    title(['Annualized Mean Wind Speed Over the Years for ' hub_heights{h}]);
    grid on;
end

% Seasonal comparison
for h = 1:length(hub_heights)
    figure;
    bar(1:length(seasons), [seasonal_means_east(:, h), seasonal_means_west(:, h)]);
    xlabel('Seasons');
    ylabel('Average Wind Speed (m/s)');
    xticks(1:length(seasons));
    xticklabels(seasons);
    legend(['East ' + string(hub_heights{h}), 'West ' + string(hub_heights{h})], 'Location', 'best');
    title(['Seasonal Average Wind Speed for ' hub_heights{h}]);
    grid on;
end
%% Wind Speed > 12m/s over the seasons

% Determine the season for each entry in the dataset
dates = datetime(wind.Time, 'InputFormat', 'yyyy/MM/dd HH:mm');
months = month(dates);

% Defining seasons (Southern Hemisphere)
isAutumn = ismember(months, [3, 4, 5]);
isWinter = ismember(months, [6, 7, 8]);
isSpring = ismember(months, [9, 10, 11]);
isSummer = ismember(months, [12, 1, 2]);

% For 100m height, find the occurrences where 12 m/s < speed < 25 m/s
in_range = (wind.S100 > 12) & (wind.S100 < 25);

% Calculate percentage of time steps in the specified range for each season
autumn_perc = mean(in_range(isAutumn)) * 100;
winter_perc = mean(in_range(isWinter)) * 100;
spring_perc = mean(in_range(isSpring)) * 100;
summer_perc = mean(in_range(isSummer)) * 100;

% Display results
disp(['Percentage of time steps with 12 m/s < wind speed < 25 m/s during Autumn: ', num2str(autumn_perc), '%']);
disp(['Percentage of time steps with 12 m/s < wind speed < 25 m/s during Winter: ', num2str(winter_perc), '%']);
disp(['Percentage of time steps with 12 m/s < wind speed < 25 m/s during Spring: ', num2str(spring_perc), '%']);
disp(['Percentage of time steps with 12 m/s < wind speed < 25 m/s during Summer: ', num2str(summer_perc), '%']);

%% Turbulence Intensity by Wind Speed Bin
% Define hub heights or velocity sensor names
sensor_names = {'S20', 'S60', 'S100', 'S120', 'S160'};

% Preallocate memory
results_data = struct();
windowSize = 6; % 6 readings for an hour, given 10-minute sampling

% High TI threshold
high_TI_threshold = 0.25;

% Calculate rolling turbulence intensity for each sensor
for i = 1:length(sensor_names)
    speed_data = wind.(sensor_names{i});
    direction_data = wind.(['D' sensor_names{i}(2:end)]); % Assuming Dxx corresponds to direction

    rollAvg = movmean(speed_data, windowSize);
    rollStd = movstd(speed_data, windowSize);
    TI = rollStd ./ rollAvg;
    
    % Store the results
    results_data.(sensor_names{i}).TI = TI;
    results_data.(sensor_names{i}).mean_speed = rollAvg;
    results_data.(sensor_names{i}).direction = direction_data;

    % Quantitative Metrics
    results_data.(sensor_names{i}).avg_TI = mean(TI);
    results_data.(sensor_names{i}).median_TI = median(TI);
    results_data.(sensor_names{i}).q1_TI = quantile(TI, 0.25);
    results_data.(sensor_names{i}).q3_TI = quantile(TI, 0.75);
    results_data.(sensor_names{i}).iqr_TI = results_data.(sensor_names{i}).q3_TI - results_data.(sensor_names{i}).q1_TI;
    results_data.(sensor_names{i}).std_TI = std(TI);
    results_data.(sensor_names{i}).max_TI = max(TI);
    results_data.(sensor_names{i}).min_TI = min(TI);
    results_data.(sensor_names{i}).high_TI_freq = sum(TI > high_TI_threshold) / length(TI);
    results_data.(sensor_names{i}).directional_std = std(direction_data);

    % Scatter Plot Visualization with Color Bar Label
    figure;
    scatter(rollAvg, TI, 10, direction_data, 'filled');
    title(['Turbulence Intensity vs. Wind Speed for ' sensor_names{i}]);
    xlabel('Mean Wind Speed (m/s)');
    ylabel('Turbulence Intensity');
    caxis([0 360]);
    colormap('hsv'); % Using hue-saturation-value colormap to represent direction
    grid on;
    
    % Add label to color bar
    cb = colorbar;
    cb.Label.String = 'Wind Direction (°)';
end
% Display the calculated metrics for each sensor
for i = 1:length(sensor_names)
    sensor = sensor_names{i};
    disp(['Metrics for ' sensor ':']);
    disp(['Average TI: ' num2str(results_data.(sensor).avg_TI)]);
    disp(['Median TI: ' num2str(results_data.(sensor).median_TI)]);
    disp(['25th Percentile (Q1) TI: ' num2str(results_data.(sensor).q1_TI)]);
    disp(['75th Percentile (Q3) TI: ' num2str(results_data.(sensor).q3_TI)]);
    disp(['Interquartile Range (IQR) TI: ' num2str(results_data.(sensor).iqr_TI)]);
    disp(['Standard Deviation of TI: ' num2str(results_data.(sensor).std_TI)]);
    disp(['Max TI: ' num2str(results_data.(sensor).max_TI)]);
    disp(['Min TI: ' num2str(results_data.(sensor).min_TI)]);
    disp(['Frequency of High TI Events: ' num2str(results_data.(sensor).high_TI_freq)]);
    disp(['Directional Consistency (Std Dev of Direction): ' num2str(results_data.(sensor).directional_std)]);
    disp('-----------------------------------------------');
end

%% Histogram-Based Analysis of Average Turbine Power and Capacity Factor using KDE
% Load the CSV file

% List of hub heights to process
hub_heights = {'S20', 'S60', 'S100', 'S120', 'S160'};

% Wind turbine rated power (W)
Prated = 8000e3; % for Vestas  V164-8.0 MW

% Loop through each hub height
for i = 1:length(hub_heights)
    hub_height = hub_heights{i};
    wind_speeds = wind.(hub_height);
    
    % KDE for wind speed distribution
    [f, xi] = ksdensity(wind_speeds, 'Bandwidth', 0.5); % 0.5 is a typical bandwidth for wind speeds, but it might need fine-tuning
    
    % Compute Pavgshort using the power curve and the KDE density
    dx = mean(diff(xi)); % integral steps (m/s)
    Pavgshort = sum(fcnpowercurve(xi, Prated) .* f) * dx;
    
    % Compute short-term capacity factor
    CFshort = Pavgshort / Prated;
    
    % Display results
    disp(['For ' hub_height ':'])
    disp(['Assumed wind turbine rated power (MW): ' num2str(Prated/1e6,'%3.1f')])
    disp(['Histogram-Based Av. power (kW): ' num2str(Pavgshort/1e3,'%3.0f')])
    disp(['Histogram-Based Capacity Factor (%): ' num2str(CFshort*100,'%2.0f')])
    disp(' ')
    
    % Plotting the power curve for this hub height
    figure;
    plot(xi, fcnpowercurve(xi, Prated), 'LineWidth', 2);
    hold on; % Keep the current plot active
    
    % Add round dots for each wind speed from the KDE
    plot(xi, fcnpowercurve(xi, Prated), 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r');
    
    xlabel('Wind Speed (m/s)');
    ylabel('Power (W)');
    title(['Power Curve for ' hub_height]);
    xlim([0 25]);  % Setting the x-axis limits to [0, 25]
    grid on;
end

clear Prated Pavgshort dx CFshort
%% Weibull-Fitted Analysis of  Power and Capacity Factor*
% Load the dataset

% List of hub heights for which we want to perform the analysis
hub_heights = {'S20', 'S60', 'S100', 'S120', 'S160'};

% Wind turbine rated power (W)
Prated = 8000e3;

% Loop through each hub height
for i = 1:length(hub_heights)
    hub_height = hub_heights{i};
    
    % Extract wind speed data for the current hub height
    vhub = wind.(hub_height);
    % Remove non-positive values
    vhub = vhub(vhub > 0);
    
    % Weibull fit to wind speed data with a fallback using initial estimates
    try
        [paramEsts, ~] = wblfit(vhub);
    catch
        disp(['Initial Weibull fitting failed for hub height ' hub_height '. Using fallback initial estimates.']);
        initialEstimates = [mean(vhub), std(vhub)]; 
        [paramEsts, ~] = wblfit(vhub, 'Start', initialEstimates);
    end
    
    pd = makedist('Weibull','a',paramEsts(1),'b',paramEsts(2));

    % Estimate wind speed distribution at hub height for the long term average
    vbins = (0:1:ceil(max(vhub)))';
    vltpdf = pdf(pd, vbins);
    
    % Compute Pavglong as the integral of the wind turbine power curve and the
    % pdf of the wind speed at the hub height.
    dx = mean(diff(vbins)); % integral steps (m/s)
    Pavglong = sum(fcnpowercurve(vbins, Prated) .* vltpdf) * dx;
    
    % Compute long-term capacity factor
    CFlong = Pavglong / Prated;
    
    % Display results
    disp(['For ' hub_height 'm Hub Height:']);
    disp(['Assumed wind turbine rated power (MW): ' num2str(Prated/1e6,'%3.1f')])
    disp(['Weibull-Fitted Av. Power (kW): ' num2str(Pavglong/1e3,'%3.0f')])
    disp(['Weibull-Fitted Capacity Factor (%): ' num2str(CFlong*100,'%2.0f')])
    disp('---------------------------------------------');
    
    % Diagnostic Plots
    figure;
    subplot(2,1,1);
    vrange = 0:0.1:max(vbins);
    plot(vrange, fcnpowercurve(vrange, Prated));
    xlabel('Wind Speed (m/s)');
    ylabel('Power (W)');
    title(['Power Curve for Hub Height ' hub_height 'm']);
    
    subplot(2,1,2);
    histogram(vhub, 'Normalization', 'pdf');
    hold on;
    plot(vbins, vltpdf, 'r', 'LineWidth', 2);
    xlabel('Wind Speed (m/s)');
    ylabel('Probability Density');
    title(['Wind Speed Distribution and Weibull Fit for ' hub_height 'm']);
    legend('Empirical Distribution', 'Weibull Fit');
end

%% Wind Shear Analysis

% Hub heights (in meters)
z = [20, 60, 100, 160];

% Extract wind speed data for each hub height
v = [mean(wind.S20), mean(wind.S60), mean(wind.S100), mean(wind.S160)];

% Choose reference height (for example, 100m)
z_ref = 100;
v_ref = mean(wind.S100);

% Perform linear regression to find alpha (wind shear coefficient)
p = polyfit(log(z/z_ref), log(v/v_ref), 1);
alpha = p(1);

% Display the wind shear coefficient
disp(['Wind Shear Coefficient (alpha): ', num2str(alpha)]);

% Visualize the measured vs. predicted wind speeds based on the power law
v_pred = v_ref * (z/z_ref).^alpha;

figure;
plot(z, v, 'o', z, v_pred, '-');
xlabel('Hub Height (m)');
ylabel('Wind Speed (m/s)');
legend('Measured Wind Speed', 'Predicted Wind Speed');
title('Wind Shear Analysis');
grid on;
%% Extreme Wind Analysis
% Investigate the extreme wind speeds at different hub heights.

% Hub heights
hub_heights = {'S20', 'S60', 'S100', 'S120', 'S160'};

% Preallocate memory for storing extreme wind statistics
extreme_stats = struct();

% Calculate extreme wind statistics for each hub height
for i = 1:length(hub_heights)
    % Maximum wind speed
    extreme_stats.(hub_heights{i}).max_speed = max(wind.(hub_heights{i}));
    
    % 99th percentile wind speed
    extreme_stats.(hub_heights{i}).p99_speed = prctile(wind.(hub_heights{i}), 99);
    
    % 1st percentile wind speed (for understanding lulls)
    extreme_stats.(hub_heights{i}).p01_speed = prctile(wind.(hub_heights{i}), 1);
    
    % Mean wind speed
    extreme_stats.(hub_heights{i}).mean_speed = mean(wind.(hub_heights{i}));
    
    % Display the results
    disp(['For ' hub_heights{i} ':']);
    disp(['Maximum Wind Speed: ', num2str(extreme_stats.(hub_heights{i}).max_speed), ' m/s']);
    disp(['99th Percentile Wind Speed: ', num2str(extreme_stats.(hub_heights{i}).p99_speed), ' m/s']);
    disp(['1st Percentile Wind Speed (for lulls): ', num2str(extreme_stats.(hub_heights{i}).p01_speed), ' m/s']);
    disp(['Mean Wind Speed: ', num2str(extreme_stats.(hub_heights{i}).mean_speed), ' m/s']);
    disp('---------------------------------------------');
end
% Visualization
figure;
for i = 1:length(hub_heights)
    subplot(length(hub_heights), 1, i);
    histogram(wind.(hub_heights{i}), 50);
    xlabel('Wind Speed (m/s)');
    ylabel('Frequency');
    title(['Wind Speed Distribution for ' hub_heights{i}]);
    grid on;
    xlim([0, ceil(extreme_stats.(hub_heights{i}).max_speed)]);
end
%% Wind Power Density Analysis

% Constants
rho = 1.225; % Air density in kg/m^3

% Hub heights
hub_heights = {'S20', 'S60', 'S100', 'S120', 'S160'};
years = unique(year(wind.t)); % Extract unique years from the data

% Preallocate memory
power_density = zeros(length(years), length(hub_heights));

% Calculate yearly wind power density for each hub height
for i = 1:length(hub_heights)
    for j = 1:length(years)
        idx = year(wind.t) == years(j);
        v_avg = mean(wind{idx, hub_heights{i}});
        power_density(j, i) = 0.5 * rho * v_avg^3;
    end 
end 

% Calculate and display mean wind power density for 100m hub height
index_S100 = strcmp(hub_heights, 'S100');
mean_power_density_S100 = mean(power_density(:, index_S100));
fprintf('Mean Wind Power Density for 100m Hub Height: %f W/m^2\n', mean_power_density_S100);

% Visualization
figure;
plot(years, power_density, '-o');
xlabel('Year');
ylabel('Wind Power Density (W/m^2)');
legend(hub_heights, 'Location', 'Best');
title('Yearly Wind Power Density for Different Hub Heights');
grid on;
%%
clear all; close all;