% Define the Turbine Layout
nTurbines = 10;
positions = [linspace(0, 5000, nTurbines)', zeros(nTurbines, 1)];

% Load Data
data = readtable('southernMostTip.csv');

for varName = data.Properties.VariableNames
    if isnumeric(data.(varName{1}))
        meanValue = nanmean(data.(varName{1}));
        data.(varName{1})(isnan(data.(varName{1}))) = meanValue;
    end
end
windSpeeds = data.S100;
windDirections = data.D100;

% Initialize Variables
D = 164; % Diameter of Vestas V164 in meters
CT = 0.8; % A typical value
powerOutput = zeros(length(windSpeeds), 1);

% Compute Wake Effect
for t = 1:length(windSpeeds)
    affectedWindSpeeds = windSpeeds(t) * ones(nTurbines, 1);
    wind_dir_vector = [cosd(windDirections(t)), sind(windDirections(t))];

    for i = 1:nTurbines
        for j = 1:nTurbines
            if j ~= i
                relative_position = positions(j, :) - positions(i, :);
                distance_along_wind = dot(relative_position, wind_dir_vector);
                
                if distance_along_wind > 0 % The turbine j is downstream of turbine i
                    affectedWindSpeeds(j) = jensenWake(affectedWindSpeeds(i), distance_along_wind, D, CT);
                end
            end
        end
    end

    affectedWindSpeeds(affectedWindSpeeds < 0) = 0;
    turbinePowers = arrayfun(@(v) fcnpowercurve(v), affectedWindSpeeds);
    powerOutput(t) = sum(turbinePowers);
end
% Introduce downtime
downtime_percentage = 0.05;
downtime_indices = randi([1, length(powerOutput)], floor(downtime_percentage * length(powerOutput)), 1);
powerOutput(downtime_indices) = 0;


% Convert powerOutput from W to kW
powerOutput = powerOutput / 1e9; % Convert from W to kW

% Apply the capacity factor
capacity_factor = 0.58; %adjust per location using CF calculated in WRA
powerOutput = powerOutput * capacity_factor;

% Aggregate the power output to monthly averages across all years
months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; % Days in each month (non-leap year)
leapYearMonths = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; % Days in each month (leap year)

% Determine number of years in dataset
numYears = ceil(length(powerOutput) / (2 * 24 * 365.25));

monthlyAverages = zeros(12, 1);
annualTotals = zeros(numYears, 1);

idxStart = 1;
for year = 1:numYears
    if mod(year, 4) == 0 % Simple criteria for leap year
        monthDays = leapYearMonths;
    else
        monthDays = months;
    end
    for month = 1:12
        idxEnd = idxStart + monthDays(month) * 2 * 24 - 1;
        
        if idxEnd > length(powerOutput) % Avoid index going out of bounds
            idxEnd = length(powerOutput);
        end
        
        monthlyData = powerOutput(idxStart:idxEnd);
        
        monthlyAverages(month) = monthlyAverages(month) + sum(monthlyData);
        annualTotals(year) = annualTotals(year) + sum(monthlyData);
        
        idxStart = idxEnd + 1;
    end
end

% Divide by the number of years to get average for each month
monthlyAverages = monthlyAverages / numYears;

%% Visualization for Monthly Averages
figure;
bar(monthlyAverages);
xlabel('Month');
ylabel('Average Monthly Power Generated (GW)');
title('Average Monthly Wind Farm Power Generation over All Years');
xticks(1:12);
xticklabels({'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'});

% Displaying the Annual Power in a Table
T = table((1:numYears)', annualTotals, 'VariableNames', {'Year', 'Total_Power_GW'});
disp(T);
