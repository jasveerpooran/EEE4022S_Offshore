function predictions = rolling_forecast(net, data, num_forecasts, window_size)
    predictions = zeros(num_forecasts, 1);
    for i = 1:num_forecasts
        input_data = data(end-window_size-i+2:end-i+1);
        predictions(i) = net(input_data);
        data = [data; predictions(i)];
    end
end
