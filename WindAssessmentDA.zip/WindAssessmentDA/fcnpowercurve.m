function p = fcnpowercurve(v, ~)
    % Data points from the provided data
    windspeed = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25];
    power = [0, 100, 650, 1150, 1850, 2900, 4150, 5600, 7100, 7800, 8000, 8000, 8000, 8000, 8000, 8000, 8000, 8000, 8000, 8000, 8000, 8000, 8000]; % in kW
    
    % Convert power to W from kW
    power = power * 1e3;

    % Interpolate power values for the given wind speeds using pchip interpolation
    p = interp1(windspeed, power, v, 'pchip');
    % Apply efficiency reduction
    efficiency = 0.95;
    p = p * efficiency;

    % Ensure power is zero below the minimum windspeed and above the cut-out windspeed
    p(v < windspeed(1)) = 0;
    p(v > windspeed(end)) = 0;
end
