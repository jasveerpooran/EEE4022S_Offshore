function [XSeq, YSeq] = createSequences(data, sequenceLength)
    numObservations = size(data, 1);
    numSequences = numObservations - sequenceLength;
    XSeq = zeros(sequenceLength, 2, numSequences);
    YSeq = zeros(numSequences, 1);
    for i = 1:numSequences
        XSeq(:,:,i) = data(i:i+sequenceLength-1, [1, 2]); % Using T2 and S100 columns
        YSeq(i) = data(i+sequenceLength, 2); % Next S100 value
    end
end
