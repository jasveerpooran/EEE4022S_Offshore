function bestAlpha = findBestAlpha(trainData, testData)
    alphas = 0.01:0.01:0.99;
    bestError = Inf;
    bestAlpha = 0.1;

    for alpha = alphas
        forecasted = adaptiveForecast(trainData, testData, alpha);
        error = evaluateForecast(testData, forecasted);
        if error < bestError
            bestError = error;
            bestAlpha = alpha;
        end
    end
    %fprintf('Best Alpha Value: %f\n', bestAlpha);

end
