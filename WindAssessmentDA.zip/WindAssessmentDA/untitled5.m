% Read the data
data = readtable('Cape Town location.csv');
s100 = data.S100;

% Define parameters
alpha_range = 0.01:0.01:0.99;
train_window = 336; % 7 days
test_window = 16;   % 8 hours

% Initialize results storage
all_forecasts = [];
all_actuals = [];

% Rolling window loop
for t = 1:(length(s100) - train_window - test_window)
    train_data = s100(t:t+train_window-1);
    test_data = s100(t+train_window:t+train_window+test_window-1);
    
    [forecast, ~] = adaptive_regressive_smoothing(train_data, test_data, alpha_range);
    
    all_forecasts = [all_forecasts; forecast];
    all_actuals = [all_actuals; test_data];
end

% Compare forecasts with actuals (for example, using a plot)
plot(all_actuals, 'k-', 'DisplayName', 'Actual');
hold on;
plot(all_forecasts, 'r-', 'DisplayName', 'Forecast');
legend('show');
title('Rolling Window Forecast');
xlabel('Time');
ylabel('S100');
